﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA1_EX4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangulo area1;
            area1 = new Triangulo();

            Console.WriteLine("Insira o valor da base do triângulo");
            area1.setB(int.Parse((Console.ReadLine())));

            Console.WriteLine("Insira o valor da altura do triângulo");
            area1.setH(int.Parse((Console.ReadLine())));

            area1.calcular();

            Console.WriteLine("");

            Console.WriteLine("A área do triângulo de Base {0}m e Altura {1}m é {2}m²");
            area1.getB();
            area1.getH();
            area1.getArea();

        }
    }
}
