﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA1_EX3
{
    internal class Quadrado
    {
        private double diag;
        private double area;

        public Quadrado ()
        {
            this.diag = 0;
        }

        public Quadrado (int diag)
        {
            this.diag = diag;
        }

        public void setDiag(int diag)
        {
            this.diag = diag;
        }

        public double getDiag()
        {
            return this.diag;
        }

        public double getArea()
        {
            return this.area;
        }

        public void calcular()
        {
            this.area = Math.Pow(this.diag / Math.Sqrt(2), 2);
        }
    }
}
