using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex7
{

	internal class reais
	{
		private double cotacao;
		private double dolar;
		private double real;

		public reais ()
        {
			this.cotacao = 0;
			this.dolar = 0;
        }

		public reais (double cotacao)
        {
			this.cotacao = cotacao;
        }

		public reais(double dolar)
		{
			this.cotacao = dolar;
		}

		public void setCot(double cotacao)
		{
			this.cotacao = cotacao;
		}	

		public void setDol(double dolar)
        {
           this.dolar = dolar ;
        }

		public double getCot()
		{
			return cotacao;
		}

		public double getDol()
		{
			return this.dolar;
		}

		public double getReal()
        {
             return this.real;
        }

		public void calcular()
		{
			this.real = this.dolar * this.cotação;
		}
	}
}
