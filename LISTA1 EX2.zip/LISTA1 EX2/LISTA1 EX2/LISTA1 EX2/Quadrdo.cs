﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA1_EX2
{
    internal class Quadrdo
    {
        private int aresta;
        private int resultado;

        public Quadrado()
        {
            this.aresta = 0;
  
        }

        public Quadrado(int aresta)
        {
            this.aresta = aresta;

        }

        public void setaresta(int aresta)
        {
           this.aresta = aresta;

        }

        public int getaresta()
        {
            return this.aresta;
        }

        public int getResultado()
        {
            return this.resultado;
        }
        public void somar()
        {
            this.resultado = this.aresta * this.aresta;
        }
    }

}
